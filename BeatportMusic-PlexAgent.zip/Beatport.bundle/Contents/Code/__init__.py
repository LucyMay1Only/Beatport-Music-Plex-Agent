# =======================================================================
# Beatport Music Metadata Agent for Plex
# 
# Copyright (c) 2026 Lucy May & G. Antidote
# All Rights Reserved.
# =======================================================================

import urllib
import re
import json

USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def Start():
    HTTP.CacheTime = CACHE_1WEEK
    HTTP.Headers['User-Agent'] = USER_AGENT
    HTTP.Headers['Accept-Language'] = 'en-US,en;q=0.9'

def get_next_data(html):
    try:
        json_str = html.split('<script id="__NEXT_DATA__" type="application/json">')[1].split('</script>')[0]
        return json.loads(json_str)
    except:
        return None

def find_query_data(data, keyword):
    queries = data.get('props', {}).get('pageProps', {}).get('dehydratedState', {}).get('queries', [])
    for q in queries:
        key = q.get('queryKey', [])
        if keyword in str(key):
            return q.get('state', {}).get('data', {})
    return {}

class BeatportArtist(Agent.Artist):
    name = 'Beatport'
    languages = [Locale.Language.English]
    primary_provider = True

    def search(self, results, media, lang, manual=False):
        if not media.name: return
        
        query = String.StripDiacritics(media.name).lower()
        encoded_query = urllib.quote_plus(query.encode('utf-8'))
        url = 'https://www.beatport.com/search?q=%s' % encoded_query
        
        try:
            html = HTTP.Request(url, sleep=2.0).content
            data = get_next_data(html)
            if not data: return
            
            search_data = find_query_data(data, 'search-all')
            artists = search_data.get('artists', {}).get('data', [])
            
            seen = set()
            for art in artists:
                artist_name = art.get('artist_name', '')
                artist_id = str(art.get('artist_id', ''))
                
                if artist_id and artist_id not in seen:
                    seen.add(artist_id)
                    score = 100 - Util.LevenshteinDistance(query.lower(), artist_name.lower())
                    
                    results.Append(MetadataSearchResult(id=artist_id, name=artist_name, score=score, lang=lang))
            results.Sort('score', descending=True)
            
        except Exception as e:
            Log('Beatport Artist Search Error: ' + str(e))

    def update(self, metadata, media, lang, force=False):
        artist_id = metadata.id
        # The slug doesn't matter, beatport handles it
        url = 'https://www.beatport.com/artist/a/%s' % artist_id
        
        try:
            html = HTTP.Request(url, sleep=2.0).content
            data = get_next_data(html)
            if not data: return
            
            artist_data = find_query_data(data, 'artist-%s' % artist_id)
            
            metadata.title = artist_data.get('artist_name', '')
            
            bio = artist_data.get('biography', '')
            if bio:
                # remove html tags if they exist
                bio = re.sub(r'<[^>]+>', '', bio)
                metadata.summary = bio
                
            img_url = artist_data.get('artist_image_uri')
            if img_url:
                try:
                    img_data = HTTP.Request(img_url).content
                    metadata.posters[img_url] = Proxy.Preview(img_data)
                except:
                    pass
                    
        except Exception as e:
            Log('Beatport Artist Update Error: ' + str(e))

class BeatportAlbum(Agent.Album):
    name = 'Beatport'
    languages = [Locale.Language.English]
    primary_provider = True

    def search(self, results, media, lang, manual=False):
        artist_name = media.parent_metadata.title if media.parent_metadata else ''
        album_name = media.title
        
        if not album_name: return
        
        query = '%s %s' % (artist_name, album_name)
        query = String.StripDiacritics(query.strip()).lower()
        encoded_query = urllib.quote_plus(query.encode('utf-8'))
        
        url = 'https://www.beatport.com/search?q=%s' % encoded_query
        
        try:
            html = HTTP.Request(url, sleep=2.0).content
            data = get_next_data(html)
            if not data: return
            
            search_data = find_query_data(data, 'search-all')
            releases = search_data.get('releases', {}).get('data', [])
            
            seen = set()
            for rel in releases:
                title = rel.get('release_name', '')
                release_id = str(rel.get('release_id', ''))
                
                # Check artist to boost score
                rel_artists = rel.get('artists', [])
                matched_artist = False
                for a in rel_artists:
                    if artist_name.lower() in a.get('artist_name', '').lower():
                        matched_artist = True
                        
                score = 100 - Util.LevenshteinDistance(album_name.lower(), title.lower())
                if matched_artist:
                    score += 5
                    
                if release_id and release_id not in seen:
                    seen.add(release_id)
                    results.Append(MetadataSearchResult(id=release_id, name=title, score=score, lang=lang))
                    
            results.Sort('score', descending=True)
            
        except Exception as e:
            Log('Beatport Album Search Error: ' + str(e))

    def update(self, metadata, media, lang, force=False):
        release_id = metadata.id
        url = 'https://www.beatport.com/release/a/%s' % release_id
        
        try:
            html = HTTP.Request(url, sleep=2.0).content
            data = get_next_data(html)
            if not data: return
            
            rel_data = find_query_data(data, 'release-%s' % release_id)
            
            metadata.title = rel_data.get('release_name', '')
            
            metadata.genres.clear()
            for g in rel_data.get('genre', []):
                metadata.genres.add(g.get('genre_name'))
                
            label = rel_data.get('label', {}).get('label_name')
            if label:
                metadata.studio = label
                
            r_date = rel_data.get('new_release_date') or rel_data.get('release_date')
            if r_date:
                try:
                    # Usually returned as YYYY-MM-DD
                    date_str = r_date.split('T')[0]
                    metadata.originally_available_at = Datetime.ParseDate(date_str).date()
                except:
                    pass
                    
            img_url = rel_data.get('release_image_uri')
            if img_url:
                try:
                    # Force higher res if needed but Beatport usually returns 500x500 which is fine
                    img_data = HTTP.Request(img_url).content
                    metadata.posters[img_url] = Proxy.Preview(img_data)
                except:
                    pass
                    
        except Exception as e:
            Log('Beatport Album Update Error: ' + str(e))
